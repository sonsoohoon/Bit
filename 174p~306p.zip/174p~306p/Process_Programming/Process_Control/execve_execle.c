#include <stdio.h>


main()
{
	static char * nargv[]={"newpgm","parm1","parm2","parm3",(char*)0};

	static char * nenv[]={"NAME=VAL","nextname=nextvalu","HOME=/xy",(char*)0};

	printf("this is the original program\n");

	execve("./newpgm",nargv,nenv);
	/* execle("./newpgm", "newpgm", "parm1", "parm2", "parm3", (char*)O,nenv);*/

	printf("This line should never get printed\n");
}

