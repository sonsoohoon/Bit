#include <stdio.h>
main()
{
	static char * nargv[] = {"newpgm","parm1","parm2","parm3",(char*)0};

	printf("this is the original program\n");

	execv("./newpgm", nargv);

	printf("This line should never get printed\n");

}
