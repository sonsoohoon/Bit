#include <stdio.h>
#include <stdlib.h>


main()
{
	int fork();


	if(fork() == 0){
		execl("/bin/echo", "echo", "this is", "message one", (char*)0);
		printf("exec one failed");
		exit(1);
	}
	
	if(fork() == 0){
		execl("/bin/echo", "echo", "this is", "message two", (char*)0);
		printf("exec two failed");
		exit(2);
	}

	if(fork() == 0){
		execl("/bin/echo", "echo", "this is", "message three", (char*)0);
		printf("exec three failed");
		exit(3);
	}
	printf("Parent program ending\n");
}


