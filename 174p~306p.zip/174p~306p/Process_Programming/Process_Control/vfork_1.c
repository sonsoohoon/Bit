#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

static int glob = 6;	/* external variable in initialized data */

int main(void)
{
	int var; 	/* automatic variable on the stack */
	pid_t pid;

	var = 88;
	printf("before fork\n");

	if((pid = vfork())<0)
		printf("fork error");
	else if(pid == 0)
	{
		glob++;
		var++;
		_exit(0);
	}
	printf("pid = %d, glob = %d, var = %d\n", getpid(), glob, var);
	exit(0);
}
