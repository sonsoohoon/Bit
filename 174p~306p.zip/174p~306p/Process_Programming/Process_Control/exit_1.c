#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("exit() test");
	exit(0);
}

