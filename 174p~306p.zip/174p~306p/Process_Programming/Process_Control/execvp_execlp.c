#include <stdio.h>


main()
{
	static char * nargv[] = {"newpgm", "parm1", "parm2", "parm3", (char*)0};

	printf("this is the original program\n");

	execvp("newpgm", nargv);

	/* execlp("newpgm", "newpgm", "parm1", "parm2", "parm3",(char*)0); */

	printf("This line should never get printed\n");

}

