#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
	int stat,i;
	char * commands[] = {"uname -a","finger 'loname';exit 10", "not_a_command"};

	for(i=0; i<3; i++)
	{
		if((stat = system(commands[i]))<0)
			fprintf(stderr, "system call failed\n");
		//else
		//	term_stat(stat);  //??????????????????? where???
	}
}

