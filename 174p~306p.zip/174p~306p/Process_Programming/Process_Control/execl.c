#include <stdio.h>

main()
{
	printf("this is the original program\n");

	execl("./newpgw","newpgm","parm1","parm2","parm3",(char*)0);

	printf("This line should never get printed\n");

}
