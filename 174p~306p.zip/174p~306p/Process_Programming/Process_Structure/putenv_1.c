#include <stdio.h>
#include <stdlib.h>

extern ** environ;

char glob_var[]="HOBBY=swimming";  //Global variable
void addone()
{
	char auto_var[10]; 			// automatic variable
	strcpy(auto_var, "LOVER=wk");
	putenv(auto_var);
}

int main()
{
	int i;
	/*show ingerited environment variables*/
	for(i=0; environ[i] != NULL; i++)
		printf("environ[%d]: %s\n", i, environ[i]);

	putenv(glob_var); /* put two new environment variables */
	addone();
	printf("My hobby is %s\n", getenv("HOBBY"));
	printf("My lover is %s\n", getenv("LOVER"));
	strcpy(glob_var+6, "fishing"); /* modify environment variable */
	for(i=0; environ[i] != NULL; i++) /* show result */
		printf("environ[%d]: %s\n", i, environ[i]);
}

