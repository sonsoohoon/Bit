#include <stdio.h>

int main()
{
	int childpid, pipe1[2], pipe2[2];

	if(pipe(pipe1)< 0 || pipe(pipe2) <0)
		printf("pipe error");
	if(childpid = fork()<0)
		printf("fork error");
	else if(childpid > 0)		/* parent process */
	{
		close(pipe1[0]);
		close(pipe2[0]);
		client(pipe2[0], pipe1[1]);
		while(wait((int*)0) != childpid);

		close(pipe1[1]);
		close(pipe2[0]);
		exit(0);
	}
	else						/* child precess */
	{
		close(pipe1[1]);
		close(pipe2[0]);
		server(pipe1[0], pipe2[1]);

		close(pipe1[0]);
		close(pipe2[1]);
		exit(0);
	}
}

	
