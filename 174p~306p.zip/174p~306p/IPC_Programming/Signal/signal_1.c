#include <signal.h>
#include <stdlib.h>
#include <stdio.h>

int catchint(int signo)
{
	printf(" SIGINT Receive\n");
}

main()
{
	signal(SIGINT,(void*) catchint);

	printf("sleep call #1\n"); sleep(1);
	printf("sleep call #2\n"); sleep(1);
	printf("sleep call #3\n"); sleep(1);
	printf("sleep call #4\n"); sleep(1);
	printf("Exiting");
	exit(0);
}
